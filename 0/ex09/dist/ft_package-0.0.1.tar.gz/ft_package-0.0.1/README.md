# ft_package

This is a simple Python package for learning purposes.

## Function

- `count_in_list(lst, item)` – counts how many times `item` appears in the list `lst`.
