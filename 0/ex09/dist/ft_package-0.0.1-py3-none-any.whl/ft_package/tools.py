def count_in_list(lst, item):
    """Returns the number of times item appears in lst."""
    return lst.count(item)